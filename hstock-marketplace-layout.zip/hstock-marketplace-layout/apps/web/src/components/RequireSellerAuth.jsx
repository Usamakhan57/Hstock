import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSellerAuth } from '../context/SellerAuthContext';

const RequireSellerAuth = ({ children }) => {
  const { isAuthenticated } = useSellerAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/seller/login" replace state={{ from: location }} />;
  }
  return children;
};

export default RequireSellerAuth;
