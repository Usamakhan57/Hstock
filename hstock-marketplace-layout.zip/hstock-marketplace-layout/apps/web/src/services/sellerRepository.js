/**
 * sellerRepository.js — Single source of truth for storefront sellers
 * ("artists" in older storefront copy).
 *
 * Reads from `pm_admin_sellers` (written by the Admin Sellers panel) and
 * maps the admin schema to the storefront shape every seller-facing page
 * needs (profile header, product-card byline, verified badge).
 *
 * WHY THIS FILE: the storefront used to import a hardcoded `artists` array
 * from data.js — completely disconnected from the Admin Sellers panel, the
 * same gap that was previously closed for Categories (categoryRepository.js)
 * and Products (productRepository.js). Sellers created/renamed/approved in
 * Admin never appeared on `/seller/:slug`, and — critically — every product
 * card links to `/seller/${slugify(product.artist)}`, so once the seller
 * catalog changed (e.g. the HStock rebrand) those links 404'd against the
 * stale hardcoded list. This file closes that gap the same way.
 *
 * Only `approved` sellers are exposed to the storefront — pending/rejected
 * sellers have no public profile or products yet.
 *
 * Rating and sales figures are intentionally NOT stored on the seller
 * record — they're always computed live from that seller's actual visible
 * products (via productRepository), so they can never drift out of sync,
 * mirroring the same principle used for category product counts.
 */
import { seedSellers } from '../admin/api/seedData';
import { slugify } from '../data';
import { loadStorefrontProducts } from './productRepository';

const STORAGE_KEY = 'pm_admin_sellers';

function loadRawSellers() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // corrupted — fall through to seed
  }
  return seedSellers;
}

/** First letter of up to the first two words of a store name, e.g. "Nexus Apps" → "NA". */
function initialsFor(name) {
  return (name || '')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('') || '?';
}

/** Compact display count, e.g. 12400 → "12.4k", 340 → "340". */
function formatCount(n) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

/** Small deterministic string hash so mock stats stay stable per seller across renders. */
function hashString(str) {
  let h = 0;
  for (let i = 0; i < (str || '').length; i++) {
    h = (h * 31 + str.charCodeAt(i)) >>> 0;
  }
  return h;
}

const RESPONSE_TIME_OPTIONS = ['Within an hour', 'Within a few hours', 'Within 24 hours', 'Within 2 days'];
const LAST_ACTIVE_OPTIONS = ['Online now', 'Active today', 'Active yesterday', 'Active this week'];

/** Deterministic mock response time — no real messaging backend exists yet. */
function responseTimeFor(seller) {
  return RESPONSE_TIME_OPTIONS[hashString(seller.id) % RESPONSE_TIME_OPTIONS.length];
}

/** Deterministic mock "last active" indicator — same reasoning as responseTimeFor. */
function lastActiveFor(seller) {
  return LAST_ACTIVE_OPTIONS[hashString(seller.id + 'la') % LAST_ACTIVE_OPTIONS.length];
}

/** Map one admin-schema seller to the storefront shape, enriched with live product stats. */
function mapToStorefront(seller) {
  const name = seller.storeName;
  const products = loadStorefrontProducts().filter((p) => p.artist === name);
  const totalDownloads = products.reduce((sum, p) => sum + (p.downloads || 0), 0);
  const avgRating = products.length > 0
    ? Math.round((products.reduce((sum, p) => sum + (p.rating || 0), 0) / products.length) * 10) / 10
    : 0;

  return {
    id: seller.id,
    name,
    slug: slugify(name),
    initials: initialsFor(name),
    bio: seller.bio || '',
    specialty: seller.specialty || '',
    verified: !!seller.verified,
    rating: avgRating,
    sales: formatCount(totalDownloads),
    totalSalesAmount: seller.totalSales || 0,
    joined: seller.joinedAt ? String(new Date(seller.joinedAt).getFullYear()) : '',
    joinedAt: seller.joinedAt || null,
    productCount: products.length,
    responseTime: responseTimeFor(seller),
    lastActive: lastActiveFor(seller),
  };
}

/** All storefront-visible (approved) sellers, mapped for display. */
export function getStorefrontSellers() {
  return loadRawSellers()
    .filter((s) => s.status === 'approved')
    .map(mapToStorefront);
}

/** A single seller by slug, or null. Powers /seller/:slug. */
export function getSellerBySlug(slug) {
  return getStorefrontSellers().find((s) => s.slug === slug) || null;
}

/** Every visible product belonging to a seller, by store name (matches product.artist). */
export function getSellerProducts(name) {
  return loadStorefrontProducts().filter((p) => p.artist === name);
}

/**
 * Resolve a seller/brand display name to its verified status — used by
 * productRepository so product cards can show a verified badge without
 * duplicating seller data on every product.
 */
export function resolveSellerVerified(name) {
  if (!name) return false;
  const found = loadRawSellers().find((s) => s.storeName === name && s.status === 'approved');
  return !!found?.verified;
}
