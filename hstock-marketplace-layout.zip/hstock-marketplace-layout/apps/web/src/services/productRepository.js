/**
 * productRepository.js — Single source of truth for storefront products.
 *
 * Reads from `pm_admin_products` (written by the Admin CRUD panel) and
 * maps the admin schema to the storefront product shape expected by every
 * page and component.
 *
 * WHY ONE FILE: previously the storefront used a hardcoded `products` array
 * from data.js while the admin wrote to localStorage under pm_admin_products.
 * This file bridges that gap so Admin-created products appear immediately on
 * the storefront — no duplicated repositories, no mock arrays.
 *
 * Schema mapping (admin → storefront):
 *   thumbnail        → img
 *   gallery[0]       → images[0]
 *   categoryId name  → cat  (resolved via categoryRepository — the single
 *                            shared category service, not a local copy)
 *   brandId name     → artist (resolved via live pm_admin_brands, falling
 *                            back to seedBrands, by id)
 *   salePrice ?? price → price
 *   price (original) → old  (only when salePrice is set)
 *   featured         → badge: 'Featured'
 *   status 'active' or 'published' → visible; 'draft'/'archived' → hidden
 */

import { seedProducts, seedBrands } from '../admin/api/seedData';
import { licenseCatalog, slugify } from '../data';
import { resolveCategoryName, resolveCategorySlug } from './categoryRepository';

const STORAGE_KEY = 'pm_admin_products';
const BRANDS_STORAGE_KEY = 'pm_admin_brands';

/**
 * Load an admin entity list (brands, ...) from its live localStorage
 * store, falling back to the seed list if storage is empty or unreadable.
 * Mirrors the same fallback pattern used for products below, so lookups
 * reflect brands created or renamed after the seed data was written — not
 * just the original seed set. (Category resolution lives entirely in
 * categoryRepository.js now — this file no longer duplicates it.)
 */
function loadEntityList(storageKey, seed) {
  try {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // corrupted — fall through to seed
  }
  return seed;
}

/**
 * Resolve a brandId to a display name, the same way categoryRepository
 * resolves categoryId. Returns null (not a fallback string) when nothing
 * matches, so callers can chain their own fallback (e.g. 'HStock').
 */
function resolveBrandName(brandId) {
  if (!brandId) return null;
  const brands = loadEntityList(BRANDS_STORAGE_KEY, seedBrands);
  const found = brands.find((b) => b.id === brandId);
  return found ? found.name : null;
}

/**
 * Resolve a guaranteed non-empty, URL-safe slug for an admin-schema product.
 * - Uses the stored slug if present.
 * - Otherwise generates one from the title (auto-slug for products created
 *   from the Admin panel without an explicit slug).
 * - Falls back to the product id if the title can't produce a usable slug
 *   (e.g. title made only of symbols), so a slug is always available.
 */
function resolveProductSlug(p) {
  const stored = typeof p.slug === 'string' ? p.slug.trim() : '';
  if (stored) return stored;

  const fromTitle = p.title ? slugify(p.title) : '';
  if (fromTitle) return fromTitle;

  return String(p.id);
}

/**
 * Map one admin-schema product to the storefront product shape.
 * Only `active` products are shown; drafts and archived are excluded.
 */
function mapAdminToStorefront(p) {
  const displayPrice = p.salePrice != null ? p.salePrice : p.price;
  const oldPrice = p.salePrice != null ? p.price : null;

  // Infer a badge: explicit badge field → sale → featured
  let badge = p.badge || null;
  if (!badge && p.salePrice != null) badge = 'Sale';
  else if (!badge && p.featured) badge = 'Featured';

  // Build licenseIds: if the admin product stores them, use as-is;
  // otherwise fall back to all three for new products.
  const licenseIds =
    Array.isArray(p.licenseIds) && p.licenseIds.length > 0
      ? p.licenseIds
      : ['personal', 'commercial'];

  // File types: admin stores fileTypes array directly or we derive from tags/title
  const fileTypes = Array.isArray(p.fileTypes) && p.fileTypes.length > 0
    ? p.fileTypes
    : ['Digital Download'];

  const rawImages = Array.isArray(p.gallery) && p.gallery.length > 0
    ? p.gallery
    : [p.thumbnail].filter(Boolean);
  const images = rawImages.length > 0 ? rawImages : [''];

  const shipping = p.shipping && typeof p.shipping === 'object' ? p.shipping : null;
  const productType = shipping?.productType || p.productType || 'digital';

  return {
    // Core identity
    id: p.id,
    title: p.title,
    slug: resolveProductSlug(p),

    // Category — storefront uses `cat` (display name string) for display
    // and filtering, plus `categoryId`/`catSlug` for links and lookups
    // that need the real category record (breadcrumbs, category pages).
    categoryId: p.categoryId || null,
    cat: typeof p.categoryId === 'string' && p.categoryId
      ? (resolveCategoryName(p.categoryId) || p.cat || 'Digital Assets')
      : (p.cat || 'Digital Assets'),
    catSlug: typeof p.categoryId === 'string' && p.categoryId
      ? resolveCategorySlug(p.categoryId)
      : null,

    // Pricing
    price: displayPrice,
    old: oldPrice,

    // Media
    img: p.thumbnail || images[0] || null,
    images,

    // Discovery
    badge,
    rating: p.rating ?? 4.5,
    reviewCount: p.reviewCount ?? 0,
    downloads: p.downloads ?? 0,
    promoted: !!p.promoted,
    featured: !!p.featured,
    promotionLabel: p.promotionLabel || null,

    // Attribution — admin schema stores a brandId reference, not a name
    // directly, so resolve it the same way categoryId is resolved above.
    artist: resolveBrandName(p.brandId) || p.artist || p.brandName || p.brand || 'HStock',

    // Product details for ProductDetailPage
    fileTypes,
    dimensions: p.dimensions || null,
    version: p.version || null,
    description: p.description || '',
    whatsIncluded: typeof p.whatsIncluded === 'string' ? p.whatsIncluded : '',
    licenseIds,
    licenses: Array.isArray(p.licenses) ? p.licenses : [],
    faqs: Array.isArray(p.faq) ? p.faq : [],

    productType,
    shipping,

    // Inventory
    sku: p.sku || null,
    unlimitedStock: p.unlimitedStock ?? null,
    stock: p.stock ?? null,
    lowStockThreshold: p.lowStockThreshold ?? null,
    barcode: p.barcode || null,

    // Extended digital-product fields
    fileSize: p.fileSize || null,
    resolution: p.resolution || null,
    orientation: p.orientation || null,
    colorSpace: p.colorSpace || null,
    requirements: p.requirements || null,
    supportedSoftware: Array.isArray(p.supportedSoftware) ? p.supportedSoftware : [],
    compatibleVersions: Array.isArray(p.compatibleVersions) ? p.compatibleVersions : [],
    liveDemoUrl: p.liveDemoUrl || null,
    shortDescription: p.shortDescription || null,

    // Pass through any extra admin fields
    featured: !!p.featured,
    status: p.status,
    tags: p.tags || [],
    createdAt: p.createdAt || new Date().toISOString(),
  };
}

/**
 * Load all products from pm_admin_products localStorage.
 * Falls back to seedProducts if localStorage is empty or unreadable.
 * Status mapping (stored value → visibility):
 *   'active'    → visible  ← what the Admin dropdown saves when label says "Published"
 *   'published' → visible  ← defensive alias (same semantic, different string)
 *   'draft'     → hidden
 *   'archived'  → hidden
 *
 * The Admin ProductForm stores `value="active"` for its "Published" option, so
 * `'active'` is the canonical live-product value. `'published'` is accepted as
 * an alias so products imported from external sources or older builds still show.
 */
const VISIBLE_STATUSES = new Set(['active', 'published']);

export function loadStorefrontProducts() {
  let raw = null;
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) raw = JSON.parse(stored);
  } catch {
    // corrupted — fall through to seed
  }

  const source = Array.isArray(raw) && raw.length > 0 ? raw : seedProducts;
  return source
    .filter((p) => VISIBLE_STATUSES.has(p.status))
    .map(mapAdminToStorefront);
}

/**
 * Find a single product by id OR slug. Powers both `/product/:id` and
 * `/product/:slug` (the route uses a single dynamic segment, so whatever the
 * visitor typed — a raw id or a human-readable slug — is resolved here).
 *
 * Searches pm_admin_products (all statuses), so direct-URL access to a
 * product page always resolves even for draft products that were previously
 * active.
 *
 * Matching order:
 *   1. Exact id match (String comparison, so numeric and string ids both work).
 *   2. Exact match against the product's stored `slug` field.
 *   3. Exact match against an auto-generated slug derived from the title,
 *      for admin products that were created/edited before a slug existed
 *      or that never had one set explicitly.
 *
 * CONTRACT: this function must NEVER return `undefined`. It always resolves
 * to either a fully-mapped storefront product object or `null`, so callers
 * (ProductDetailPage, related products, etc.) can rely on a simple falsy
 * check instead of guarding against a third "undefined" state.
 */
export function findProductById(idOrSlug) {
  // No usable lookup key at all — nothing to search for.
  if (idOrSlug === undefined || idOrSlug === null || idOrSlug === '') return null;

  let raw = null;
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) raw = JSON.parse(stored);
  } catch {
    // corrupted storage — fall through to seed
  }

  const source = Array.isArray(raw) && raw.length > 0 ? raw : seedProducts;
  const needle = String(idOrSlug);

  const found =
    source.find((p) => String(p.id) === needle) ||
    source.find((p) => typeof p.slug === 'string' && p.slug.trim() && p.slug.trim() === needle) ||
    source.find((p) => resolveProductSlug(p) === needle);

  if (!found) return null;

  // Defensive: mapAdminToStorefront should always return an object, but
  // guard against any future change accidentally introducing `undefined`.
  const mapped = mapAdminToStorefront(found);
  return mapped || null;
}

/**
 * Count of visible products per categoryId — powers the "Products Count"
 * column in the Admin Category list and the item counts shown on the
 * storefront (Header mega menu, Categories directory, Category page).
 * Always computed live from actual products, never stored, so it can
 * never drift out of sync with what's really in the catalog.
 */
export function getProductCountByCategoryId() {
  const counts = {};
  for (const p of loadStorefrontProducts()) {
    if (!p.categoryId) continue;
    counts[p.categoryId] = (counts[p.categoryId] || 0) + 1;
  }
  return counts;
}
