/**
 * collectionRepository.js — Single source of truth for storefront
 * curated Collections (distinct from Categories — a collection groups
 * products across categories around a theme).
 *
 * Reads from `pm_admin_collections` (written by the Admin Collections
 * panel) and maps the admin schema to the storefront shape CollectionsPage
 * needs. Mirrors categoryRepository.js / productRepository.js /
 * sellerRepository.js — the same bridge pattern, closing the same gap
 * (CollectionsPage previously read a hardcoded `collections` array from
 * data.js, disconnected from anything an admin actually manages).
 */
import { seedCollections } from '../admin/api/seedData';
import { slugify } from '../data';
import { loadStorefrontProducts } from './productRepository';

const STORAGE_KEY = 'pm_admin_collections';

function loadRawCollections() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // corrupted — fall through to seed
  }
  return seedCollections;
}

function resolveSlug(c) {
  const stored = typeof c.slug === 'string' ? c.slug.trim() : '';
  if (stored) return stored;
  return c.name ? slugify(c.name) : String(c.id);
}

function mapToStorefront(c) {
  return {
    id: c.id,
    slug: resolveSlug(c),
    title: c.name,
    description: c.description || '',
    cover: c.image || '',
    productIds: Array.isArray(c.productIds) ? c.productIds : [],
  };
}

/** All active collections, mapped for storefront use. */
export function getStorefrontCollections() {
  return loadRawCollections()
    .filter((c) => c.status === 'active')
    .map(mapToStorefront);
}

/** A single collection by slug, or null. */
export function getCollectionBySlug(slug) {
  return getStorefrontCollections().find((c) => c.slug === slug) || null;
}

/** Visible products belonging to a collection, by slug. */
export function getCollectionProducts(slug) {
  const collection = getCollectionBySlug(slug);
  if (!collection) return [];
  const ids = new Set(collection.productIds.map(String));
  return loadStorefrontProducts().filter((p) => ids.has(String(p.id)));
}
