/**
 * API service layer.
 *
 * Every function returns a Promise with the same shape a Node.js + Express +
 * MongoDB backend will return, so connecting the real API later is a matter
 * of replacing the body of `request()` with a `fetch(API_BASE_URL + path)`
 * call — no page or component changes required.
 *
 * PRODUCT SOURCE: all product functions now read from `productRepository`,
 * which loads from `pm_admin_products` localStorage (written by the Admin
 * CRUD panel). This makes Admin-created products appear immediately on the
 * storefront — one source of truth, zero hardcoded mock arrays.
 */
import { loadStorefrontProducts, findProductById } from './productRepository';
import { getStorefrontCategories, getCategoryBySlug, searchCategories } from './categoryRepository';
import { getStorefrontSellers, resolveSellerVerified } from './sellerRepository';
import { isManualHandover } from './productMeta';
import { PRICE_RANGES, DEFAULT_FILTERS } from '../constants';

const LATENCY = 280;

const delay = (ms = LATENCY) => new Promise((res) => setTimeout(res, ms));

/** Generic request shim — swap for fetch() when the backend is live. */
const request = async (resolver) => {
  await delay();
  return resolver();
};

/* ---------------------------------------------------------------- filters */

const applyFilters = (list, filters = DEFAULT_FILTERS) => {
  const range = PRICE_RANGES.find((r) => r.id === filters.price) || PRICE_RANGES[0];
  return list.filter((p) => {
    // `categoryNames` (an array) matches a category plus all its nested
    // subcategories — used by CategoryPage so a parent category page
    // shows products from every descendant, not just direct matches.
    // Falls back to the old single-name `category` match for flat
    // filter UIs (Shop page pills) that only ever pick one name.
    if (filters.categoryNames?.length) {
      if (!filters.categoryNames.includes(p.cat)) return false;
    } else if (filters.category && filters.category !== 'All' && p.cat !== filters.category) {
      return false;
    }
    if (p.price < range.min || p.price > range.max) return false;
    if (filters.rating && p.rating < filters.rating) return false;
    if (filters.fileTypes?.length && !filters.fileTypes.some((t) => p.fileTypes?.includes(t))) return false;
    if (filters.licenses?.length && !filters.licenses.some((l) => p.licenseIds?.includes(l))) return false;
    if (filters.deliveryTime === 'instant' && isManualHandover(p)) return false;
    if (filters.deliveryTime === 'manual' && !isManualHandover(p)) return false;
    if (filters.verifiedOnly && !resolveSellerVerified(p.artist)) return false;
    if (filters.promotedOnly && !p.promoted) return false;
    return true;
  });
};

const applySort = (list, sort) => {
  const r = [...list];
  switch (sort) {
    case 'Price: Low to High': return r.sort((a, b) => a.price - b.price);
    case 'Price: High to Low': return r.sort((a, b) => b.price - a.price);
    case 'Top Rated': return r.sort((a, b) => b.rating - a.rating);
    case 'Newest':
    case 'Date Added': return r.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    case 'Popular':
    default: return r.sort((a, b) => (b.downloads || 0) - (a.downloads || 0));
  }
};

/* ------------------------------------------------------------------- API */

export const productsApi = {
  list: ({ filters = DEFAULT_FILTERS, sort = 'Popular', query = '' } = {}) =>
    request(() => {
      const products = loadStorefrontProducts();
      let r = applyFilters(products, filters);
      if (query.trim()) {
        const needle = query.trim().toLowerCase();
        r = r.filter((p) =>
          p.title?.toLowerCase().includes(needle) ||
          p.cat?.toLowerCase().includes(needle) ||
          p.artist?.toLowerCase().includes(needle)
        );
      }
      return applySort(r, sort);
    }),

  get: (id) => request(() => findProductById(id)),

  related: (product, limit = 4) =>
    request(() => {
      const products = loadStorefrontProducts();
      return products
        .filter((p) => p.cat === product.cat && String(p.id) !== String(product.id))
        .slice(0, limit);
    }),

  popular: (limit = 12) =>
    request(() => {
      const products = loadStorefrontProducts();
      return applySort(products, 'Popular').slice(0, limit);
    }),

  // Mock "recommended for you" logic: prefer products from categories the
  // shopper has recently viewed (passed in as categoryNames), falling back
  // to overall popularity when there's no browsing history yet.
  recommended: (categoryNames = [], excludeId = null, limit = 8) =>
    request(() => {
      const products = loadStorefrontProducts().filter((p) => String(p.id) !== String(excludeId));
      if (categoryNames.length) {
        const matches = products.filter((p) => categoryNames.includes(p.cat));
        if (matches.length >= limit) return applySort(matches, 'Popular').slice(0, limit);
        const rest = applySort(products.filter((p) => !categoryNames.includes(p.cat)), 'Popular');
        return [...applySort(matches, 'Popular'), ...rest].slice(0, limit);
      }
      return applySort(products, 'Popular').slice(0, limit);
    }),

  featured: (limit = 8) =>
    request(() => {
      const products = loadStorefrontProducts();
      return products.filter((p) => p.featured).slice(0, limit);
    }),

  latest: (limit = 8) =>
    request(() => {
      const products = loadStorefrontProducts();
      return applySort(products, 'Newest').slice(0, limit);
    }),

  search: (q) =>
    request(() => {
      const products = loadStorefrontProducts();
      const needle = (q || '').trim().toLowerCase();
      if (!needle) return { products: [], categories: [], artists: [] };
      return {
        products: products.filter((p) =>
          p.title?.toLowerCase().includes(needle) ||
          p.cat?.toLowerCase().includes(needle) ||
          p.artist?.toLowerCase().includes(needle)
        ),
        categories: searchCategories(needle),
        artists: getStorefrontSellers().filter((a) => a.name.toLowerCase().includes(needle)),
      };
    }),

  /** Instant, no-latency suggestions for the live search dropdown. */
  suggest: (q, limit = 5) => {
    const products = loadStorefrontProducts();
    const needle = (q || '').trim().toLowerCase();
    if (!needle) return { products: [], categories: [], artists: [] };
    return {
      products: products.filter((p) => p.title?.toLowerCase().includes(needle)).slice(0, limit),
      categories: searchCategories(needle, 3),
      artists: getStorefrontSellers().filter((a) => a.name.toLowerCase().includes(needle)).slice(0, 3),
    };
  },
};

export const categoriesApi = {
  list: () => request(() => getStorefrontCategories()),
  bySlug: (slug) => request(() => getCategoryBySlug(slug)),
};

// collectionsApi / artistsApi / blogApi were removed — nothing in the app
// consumed them. Collections, sellers, and blog posts each have their own
// dedicated repository bridge now (collectionRepository.js,
// sellerRepository.js, services/blog/blogService.js).

export const newsletterApi = {
  subscribe: (email) => request(() => ({ ok: true, email })),
};
