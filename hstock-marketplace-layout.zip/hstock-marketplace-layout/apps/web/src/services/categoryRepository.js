/**
 * categoryRepository.js — Single source of truth for storefront categories.
 *
 * Reads from `pm_admin_categories` (written by the Admin Category CMS) and
 * maps the admin schema to whatever shape each storefront surface needs
 * (flat list, tree, breadcrumb chain, single lookup by slug). Every
 * frontend surface — Header mega menu, mobile menu, Home page, Shop
 * filters, search suggestions, category pages, breadcrumbs, product
 * pages — reads categories through this file and nothing else.
 *
 * WHY ONE FILE: this used to be a hardcoded `categories` array in
 * data.js, completely disconnected from the Admin Category CMS — a
 * category created in Admin never appeared anywhere on the storefront.
 * This file closes that gap, mirroring the same bridge pattern already
 * used for products in productRepository.js.
 *
 * Synchronous by design (like productRepository) so components that
 * need categories at first paint (Header, Hero) don't need a loading
 * state — swapping this for real `fetch()` calls later just means
 * making these functions async and awaiting them at the call sites.
 */
import {
  Frame, Image as ImageIcon, Boxes, Palette, CalendarDays, NotebookPen,
  Printer, Mail, PencilRuler, Shirt, Trophy, Leaf, Grid3x3, Layers, Dumbbell,
  Sparkles, Tag as TagIcon,
  Users, Globe2, Globe, Cloud, FileCode2, Smartphone, Bot, LayoutTemplate,
  GraduationCap, BookOpen, Terminal, Instagram, Facebook, Music2, Youtube, Twitter,
} from 'lucide-react';
import { seedCategories } from '../admin/api/seedData';
import { slugify } from '../data';
import {
  getCategoryTree, getRootCategories, getChildren, flattenCategories, getAncestors,
} from './categoryTree';

const STORAGE_KEY = 'pm_admin_categories';

/** lucide-react icon name (stored on the category) → actual component. Unknown names fall back to a generic tag icon rather than crashing. */
const ICON_MAP = {
  Frame, Image: ImageIcon, Boxes, Palette, CalendarDays, NotebookPen,
  Printer, Mail, PencilRuler, Shirt, Trophy, Leaf, Grid3x3, Layers, Dumbbell, Sparkles,
  Users, Globe2, Globe, Cloud, FileCode2, Smartphone, Bot, LayoutTemplate,
  GraduationCap, BookOpen, Terminal, Instagram, Facebook, Music2, Youtube, Twitter,
};

/** Fixed accent palette, cycled by position — keeps the existing visual style without a `color` field in the data model. */
const ACCENT_COLORS = ['#6C3BFF', '#8F63FF', '#FF4FD8'];

function loadRawCategories() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // corrupted — fall through to seed
  }
  return seedCategories;
}

/** Guaranteed non-empty, URL-safe slug for a category — uses the stored slug, or derives one from the name. */
function resolveSlug(cat) {
  const stored = typeof cat.slug === 'string' ? cat.slug.trim() : '';
  if (stored) return stored;
  return cat.name ? slugify(cat.name) : String(cat.id);
}

/** Map one admin-schema category to the storefront shape: resolved icon component, guaranteed slug, deterministic accent color. */
function mapToStorefront(cat, index) {
  return {
    ...cat,
    slug: resolveSlug(cat),
    icon: ICON_MAP[cat.icon] || TagIcon,
    color: ACCENT_COLORS[index % ACCENT_COLORS.length],
  };
}

/** All non-trashed, active categories, mapped for storefront use — the base list every other function here filters or shapes further. */
export function getStorefrontCategories() {
  return loadRawCategories()
    .filter((c) => !c.deletedAt && c.status === 'active')
    .map(mapToStorefront);
}

/** Categories flagged for the header mega menu / mobile menu, as a nested tree (unlimited depth). */
export function getHeaderCategoryTree() {
  const categories = getStorefrontCategories().filter((c) => c.showInHeader);
  return getCategoryTree(categories);
}

/** Categories flagged for the homepage grid/pills, flattened in tree (parent-then-children) order. */
export function getHomepageCategories() {
  const categories = getStorefrontCategories();
  const tree = getCategoryTree(categories);
  return flattenCategories(tree)
    .filter((c) => c.showOnHomepage)
    .map(({ depth: _depth, ...c }) => c);
}

/** Full nested category tree (all active categories), e.g. for a Categories directory page. */
export function getCategoryTreeForStorefront() {
  return getCategoryTree(getStorefrontCategories());
}

/** Root (top-level) categories only. */
export function getRootStorefrontCategories() {
  return getRootCategories(getStorefrontCategories());
}

/** Direct children of a category id. */
export function getChildCategories(categoryId) {
  return getChildren(getStorefrontCategories(), categoryId);
}

/** A single category by slug, or null. */
export function getCategoryBySlug(slug) {
  return getStorefrontCategories().find((c) => c.slug === slug) || null;
}

/** A single category by id, or null (includes inactive/trashed — used internally for resolution, not for public listing). */
export function getCategoryById(categoryId) {
  const found = loadRawCategories().find((c) => String(c.id) === String(categoryId));
  return found ? mapToStorefront(found, 0) : null;
}

/** Ancestor chain (root → … → parent), for breadcrumbs. Does not include the category itself. */
export function getCategoryAncestors(categoryId) {
  return getAncestors(getStorefrontCategories(), categoryId);
}

/** Full breadcrumb trail including the category itself, root first. */
export function getCategoryBreadcrumbTrail(categoryId) {
  const category = getCategoryById(categoryId);
  if (!category) return [];
  return [...getCategoryAncestors(categoryId), category];
}

/** Case-insensitive name search across active categories — powers search suggestions and search results. */
export function searchCategories(query, limit = 10) {
  const needle = (query || '').trim().toLowerCase();
  if (!needle) return [];
  return getStorefrontCategories().filter((c) => c.name.toLowerCase().includes(needle)).slice(0, limit);
}

/** Resolve a categoryId to its display name — used by productRepository so products never store category names directly. */
export function resolveCategoryName(categoryId) {
  if (!categoryId) return null;
  const found = loadRawCategories().find((c) => String(c.id) === String(categoryId));
  return found ? found.name : null;
}

/** Resolve a categoryId to its slug — used by productRepository/product pages for category links. */
export function resolveCategorySlug(categoryId) {
  if (!categoryId) return null;
  const found = loadRawCategories().find((c) => String(c.id) === String(categoryId));
  return found ? resolveSlug(found) : null;
}
