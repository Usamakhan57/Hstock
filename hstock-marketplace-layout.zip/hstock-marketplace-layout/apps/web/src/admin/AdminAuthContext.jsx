import React, { createContext, useContext, useState, useCallback } from 'react';

const AdminAuthContext = createContext(null);

const STORAGE_KEY = 'pm_admin_auth';

// Demo-only credentials so the panel is usable before a real backend is
// wired up. Replace `login` with a POST /api/admin/login call — keep the
// same return shape ({ ok, error }) and the rest of the panel needs no changes.
const DEMO_ADMIN = { email: 'admin@hstock.store', password: 'admin123', name: 'Ava Thompson' };

const load = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
  } catch {
    return null;
  }
};

export const AdminAuthProvider = ({ children }) => {
  const [admin, setAdmin] = useState(load);

  const login = useCallback((email, password) => {
    if (email.trim().toLowerCase() === DEMO_ADMIN.email && password === DEMO_ADMIN.password) {
      const session = { email: DEMO_ADMIN.email, name: DEMO_ADMIN.name };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
      setAdmin(session);
      return { ok: true };
    }
    return { ok: false, error: 'Invalid email or password.' };
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setAdmin(null);
  }, []);

  return (
    <AdminAuthContext.Provider value={{ admin, isAuthenticated: !!admin, login, logout }}>
      {children}
    </AdminAuthContext.Provider>
  );
};

export const useAdminAuth = () => {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within AdminAuthProvider');
  return ctx;
};
