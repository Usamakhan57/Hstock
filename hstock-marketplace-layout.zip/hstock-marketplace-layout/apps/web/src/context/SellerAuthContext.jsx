import React, { createContext, useContext, useState, useCallback } from 'react';

const SellerAuthContext = createContext(null);

const SESSION_KEY = 'pm_seller_session';
const SELLERS_KEY = 'pm_sellers';

const load = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};

// Mock seller "database" in localStorage. Swap `register`/`login` for real
// POST /api/seller/register and /api/seller/login calls later — both keep
// the same { ok, error } return shape so SellerRegisterPage/SellerLoginPage
// don't need to change.
export const SellerAuthProvider = ({ children }) => {
  const [seller, setSeller] = useState(() => load(SESSION_KEY, null));

  const register = useCallback(({ storeName, name, email, password }) => {
    const sellers = load(SELLERS_KEY, []);
    if (sellers.some((s) => s.email.toLowerCase() === email.trim().toLowerCase())) {
      return { ok: false, error: 'An account with this email already exists.' };
    }
    const joinedAt = new Date().toISOString();
    const newSeller = { storeName: storeName.trim(), name: name.trim(), email: email.trim(), password, joinedAt };
    localStorage.setItem(SELLERS_KEY, JSON.stringify([...sellers, newSeller]));
    const session = { storeName: newSeller.storeName, name: newSeller.name, email: newSeller.email, joinedAt };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setSeller(session);
    return { ok: true };
  }, []);

  const login = useCallback((email, password) => {
    const sellers = load(SELLERS_KEY, []);
    const found = sellers.find((s) => s.email.toLowerCase() === email.trim().toLowerCase() && s.password === password);
    if (!found) return { ok: false, error: 'Invalid email or password.' };
    const session = { storeName: found.storeName, name: found.name, email: found.email, joinedAt: found.joinedAt || null };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setSeller(session);
    return { ok: true };
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(SESSION_KEY);
    setSeller(null);
  }, []);

  return (
    <SellerAuthContext.Provider value={{ seller, isAuthenticated: !!seller, register, login, logout }}>
      {children}
    </SellerAuthContext.Provider>
  );
};

export const useSellerAuth = () => {
  const ctx = useContext(SellerAuthContext);
  if (!ctx) throw new Error('useSellerAuth must be used within SellerAuthProvider');
  return ctx;
};
