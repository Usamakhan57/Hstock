# SESSION_JOURNAL.md (rotated - earlier entries trimmed)

el":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 16:53:28.486Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 16:53:47.400Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 16:53:53.152Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 16:54:04.736Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 16:54:11.601Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 16:54:14.459Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 16:54:16.013Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 16:54:22.418Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 16:54:31.808Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 16:54:50.968Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 17:06:28.167Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":"radix-:r8f:","placeholder":null,"label":null,"value":null,"valueLength":0,"text":"How do I become a seller?"}

## 2026-07-28 17:06:50.200Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 17:09:15.985Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 17:09:29.575Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmSeller mode"}

## 2026-07-28 17:15:03.064Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 17:15:05.918Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmSeller mode"}

## 2026-07-28 17:15:12.182Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmSeller mode"}

## 2026-07-28 17:18:19.140Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 17:18:26.515Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 17:21:07.795Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 17:41:29.402Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 17:41:50.942Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmSeller mode"}

## 2026-07-28 17:41:52.869Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 18:04:31.436Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 18:04:34.426Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 18:34:19.469Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:19.512Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:19.550Z console.error
- text: 
    The above error occurred in the <SellerSidebar> component:
    
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)
        at div
        at div
        at div
        at header
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785263656473:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258892902:104:38)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-28 18:34:19.555Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19251:20) {"componentStack":"\n    at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)\n    at div\n    at div\n    at div\n    at header\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785263656473:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258892902:104:38)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router ...

## 2026-07-28 18:34:20.125Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:20.307Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:20.397Z console.error
- text: 
    The above error occurred in the <SellerSidebar> component:
    
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)
        at div
        at div
        at div
        at header
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785263656473:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258905302:104:38)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-28 18:34:20.402Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19251:20) {"componentStack":"\n    at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)\n    at div\n    at div\n    at div\n    at header\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785263656473:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258905302:104:38)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router ...

## 2026-07-28 18:34:32.467Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:32.724Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:32.870Z console.error
- text: 
    The above error occurred in the <SellerSidebar> component:
    
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)
        at div
        at div
        at div
        at header
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785263671788:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258892902:104:38)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-28 18:34:32.871Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19251:20) {"componentStack":"\n    at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)\n    at div\n    at div\n    at div\n    at header\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785263671788:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258892902:104:38)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router ...

## 2026-07-28 18:34:33.180Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:33.630Z window.error
- message: Uncaught ReferenceError: require is not defined
- source: http://localhost:3000/src/components/SellerSidebar.jsx
- line: 19
- col: 83
- stack: 
    ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:3705:24)

## 2026-07-28 18:34:33.873Z console.error
- text: 
    The above error occurred in the <SellerSidebar> component:
    
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)
        at div
        at div
        at div
        at header
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785263671788:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258905302:104:38)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-28 18:34:33.874Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: require is not defined
        at http://localhost:3000/src/components/SellerSidebar.jsx:19:83
        at mountMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12242:27)
        at Object.useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:12566:24)
        at useMemo (http://localhost:3000/node_modules/.vite/deps/chunk-CSEPLYDG.js?v=a3ceddef:1094:29)
        at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:17:21)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=a3ceddef:19251:20) {"componentStack":"\n    at SellerSidebar (http://localhost:3000/src/components/SellerSidebar.jsx:11:26)\n    at div\n    at div\n    at div\n    at header\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785263671788:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785258905302:104:38)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=a3ceddef:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router ...

## 2026-07-28 18:35:59.140Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 18:36:04.367Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmSeller mode"}

## 2026-07-28 18:36:17.244Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmSeller mode"}

## 2026-07-28 18:36:59.215Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 18:37:08.671Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-28 18:43:06.069Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Dashboard"}

## 2026-07-28 18:43:06.075Z navigate
- url: http://localhost:3000/seller/dashboard
- via: pushState

## 2026-07-28 18:43:38.666Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 18:43:55.221Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 18:44:03.156Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Add Product"}

## 2026-07-28 18:44:03.158Z navigate
- url: http://localhost:3000/seller/products/new
- via: pushState

## 2026-07-28 18:44:16.387Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Back"}

## 2026-07-28 18:44:16.391Z navigate
- url: http://localhost:3000/seller/products
- via: pushState

## 2026-07-28 18:44:59.627Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Overview"}

## 2026-07-28 18:44:59.632Z navigate
- url: http://localhost:3000/seller/overview
- via: replaceState

## 2026-07-28 18:44:59.634Z navigate
- url: http://localhost:3000/seller/overview
- via: pushState

## 2026-07-28 18:45:10.745Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 18:45:13.009Z navigate
- url: http://localhost:3000/
- via: replaceState

## 2026-07-28 18:45:50.020Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Shop"}

## 2026-07-28 18:45:50.023Z navigate
- url: http://localhost:3000/shop
- via: pushState

## 2026-07-28 18:48:18.180Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:48:19.996Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:48:20.785Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:48:21.594Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:48:24.368Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:48:24.610Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:50:06.994Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:50:08.088Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:50:13.003Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:50:13.031Z console.error
- text: [vite] Failed to reload /src/pages/ShopPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 18:59:54.118Z load
- url: http://localhost:3000/shop
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 19:00:14.358Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-28 19:00:14.362Z navigate
- url: http://localhost:3000/
- via: pushState

## 2026-07-28 19:00:18.001Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Categories"}

## 2026-07-28 19:00:23.146Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Categories"}

## 2026-07-28 19:14:47.460Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=a3ceddef' does not provide an export named 'Reddit'

## 2026-07-28 19:14:47.463Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:14:51.611Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=a3ceddef' does not provide an export named 'Reddit'

## 2026-07-28 19:14:51.612Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:15:01.619Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=a3ceddef' does not provide an export named 'Reddit'

## 2026-07-28 19:15:01.622Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:15:01.539Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=a3ceddef' does not provide an export named 'Reddit'

## 2026-07-28 19:15:01.539Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:16:29.227Z console.error
- text: 
    [vite] ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266186263:95:37

## 2026-07-28 19:16:29.229Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:16:29.941Z console.error
- text: 
    [vite] ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266186263:95:37

## 2026-07-28 19:16:29.941Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:16:35.581Z console.error
- text: 
    [vite] ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-28 19:16:35.586Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:16:35.432Z console.error
- text: 
    [vite] ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-28 19:16:35.432Z console.error
- text: [vite] Failed to reload /src/pages/HomePage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-28 19:19:05.697Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 19:19:07.488Z window.error
- message: Uncaught ReferenceError: Reddit is not defined
- source: http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145
- line: 95
- col: 37
- stack: 
    ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-28 19:19:33.250Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 19:19:34.796Z window.error
- message: Uncaught ReferenceError: Reddit is not defined
- source: http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145
- line: 95
- col: 37
- stack: 
    ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-28 19:19:50.760Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-28 19:19:52.725Z window.error
- message: Uncaught ReferenceError: Reddit is not defined
- source: http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145
- line: 95
- col: 37
- stack: 
    ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-29 06:56:44.515Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 06:56:46.623Z window.error
- message: Uncaught ReferenceError: Reddit is not defined
- source: http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145
- line: 95
- col: 37
- stack: 
    ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-29 06:56:50.284Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 06:56:52.093Z window.error
- message: Uncaught ReferenceError: Reddit is not defined
- source: http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145
- line: 95
- col: 37
- stack: 
    ReferenceError: Reddit is not defined
        at http://localhost:3000/src/pages/HomePage.jsx?t=1785266194145:95:37

## 2026-07-29 07:03:28.796Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 07:03:43.907Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 07:04:18.417Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 07:04:18.381Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 07:04:21.117Z navigate
- url: http://127.0.0.1:3000/
- via: replaceState

## 2026-07-29 07:05:11.316Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 07:08:07.575Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jjazzySeller mode"}

## 2026-07-29 07:08:16.218Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 07:17:41.057Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:17:41.068Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:17:41.522Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:17:41.524Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:17:44.726Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:17:44.971Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:17:47.902Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:17:47.903Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:17:49.937Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:17:49.977Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:17:50.652Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:17:50.652Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:11.663Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:11.665Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:16.239Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:16.253Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:16.826Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:16.838Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:16.542Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:16.543Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:16.744Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:16.744Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:19.661Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:19.661Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:21.656Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:21.658Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:20.515Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:20.515Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:24.186Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:24.187Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:44.882Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:44.884Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:47.241Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:47.246Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:47.412Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:47.417Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:49.425Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:49.425Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:50.252Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:50.252Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:54.187Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:54.196Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:54.568Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:54.569Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:57.184Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:57.193Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:19:56.866Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:19:56.867Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:26:20.549Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:26:20.551Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:26:20.745Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:26:20.746Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:26:22.861Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:26:22.862Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:26:25.861Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:26:25.863Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:26:25.478Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:26:25.479Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:26:25.815Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/lucide-react.js?v=b8edba6c' does not provide an export named 'Storefront'

## 2026-07-29 07:26:25.816Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:30:12.836Z window.error
- message: Uncaught ReferenceError: Storefront is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785310211100
- line: 1069
- col: 40
- stack: 
    ReferenceError: Storefront is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:1069:40)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 07:30:12.878Z window.error
- message: Uncaught ReferenceError: Storefront is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785310211100
- line: 1069
- col: 40
- stack: 
    ReferenceError: Storefront is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:1069:40)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 07:30:12.910Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 07:30:12.916Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: Storefront is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:1069:40)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7...

## 2026-07-29 07:30:13.488Z window.error
- message: Uncaught ReferenceError: Storefront is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785310211100
- line: 1069
- col: 40
- stack: 
    ReferenceError: Storefront is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:1069:40)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 07:30:13.528Z window.error
- message: Uncaught ReferenceError: Storefront is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785310211100
- line: 1069
- col: 40
- stack: 
    ReferenceError: Storefront is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:1069:40)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 07:30:13.569Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 07:30:13.570Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: Storefront is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:1069:40)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785310211100:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7...

## 2026-07-29 07:30:15.401Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:30:16.021Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:30:16.136Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:30:16.459Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:30:16.553Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:30:16.892Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:32:42.905Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:32:43.150Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:32:43.250Z console.error
- text: [vite] Failed to reload /src/components/Header.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 07:33:16.771Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Seller workspace"}

## 2026-07-29 07:33:23.838Z click
- element: {"tag":"aside","role":"dialog","ariaLabel":"Seller sidebar","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmseller@example.comSellerLiveWallet$500.00Alerts0 unreadDashboardProductsOrdersDisputesWithdrawalsReferral & RewardsSettingsSupport+ Add ProductPlatform StorePromote StoreLogout"}

## 2026-07-29 07:33:24.713Z click
- element: {"tag":"aside","role":"dialog","ariaLabel":"Seller sidebar","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"PPfafarmseller@example.comSellerLiveWallet$500.00Alerts0 unreadDashboardProductsOrdersDisputesWithdrawalsReferral & RewardsSettingsSupport+ Add ProductPlatform StorePromote StoreLogout"}

## 2026-07-29 07:33:26.495Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Logout"}

## 2026-07-29 07:33:26.510Z navigate
- url: http://localhost:3000/
- via: pushState

## 2026-07-29 07:33:29.256Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 07:33:29.262Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785310383659
- line: 1019
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310383659:1019:38)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 07:33:29.267Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785310383659
- line: 1019
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310383659:1019:38)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 07:33:29.282Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310383659:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 07:33:29.283Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785310383659:1019:38)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785310383659:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13...

## 2026-07-29 07:33:32.822Z navigate
- url: http://localhost:3000/
- via: popstate

## 2026-07-29 07:55:05.947Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Seller workspace"}

## 2026-07-29 07:55:14.968Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:07:39.358Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:09:48.803Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:09:48.817Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312392451
- line: 1020
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312392451:1020:38)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:09:48.836Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312392451
- line: 1020
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312392451:1020:38)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:09:48.861Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312392451:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:09:48.863Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312392451:1020:38)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312392451:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13...

## 2026-07-29 08:10:01.504Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:10:01.527Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451
- line: 1020
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451:1020:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:10:01.571Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451
- line: 1020
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451:1020:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:10:01.603Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:10:01.605Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451:1020:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312392451:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13...

## 2026-07-29 08:10:04.595Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Reload page"}

## 2026-07-29 08:10:12.546Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:10:28.984Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Seller workspace"}

## 2026-07-29 08:10:39.834Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Products"}

## 2026-07-29 08:10:39.838Z navigate
- url: http://localhost:3000/seller/products
- via: pushState

## 2026-07-29 08:10:52.766Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:10:56.929Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:10:58.610Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"jazzy"}

## 2026-07-29 08:13:56.480Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:14:00.687Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:14:03.592Z load
- url: http://localhost:3000/seller/products
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:14:20.986Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign out"}

## 2026-07-29 08:14:20.988Z navigate
- url: http://localhost:3000/
- via: pushState

## 2026-07-29 08:14:21.014Z navigate
- url: http://localhost:3000/seller/login
- via: replaceState

## 2026-07-29 08:14:21.068Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopConcurrent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19242:13)

## 2026-07-29 08:14:21.121Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:21.139Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at SellerLoginPage (http://localhost:3000/src/pages/SellerLoginPage.jsx?t=1785312818387:13:38)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:14:21.144Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at SellerLoginPage (http://localhost:3000/src/pages/SellerLoginPage.jsx?t=1785312818387:13:38)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps...

## 2026-07-29 08:14:23.327Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Reload page"}

## 2026-07-29 08:14:23.349Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:23.395Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:23.427Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at SellerLoginPage (http://localhost:3000/src/pages/SellerLoginPage.jsx?t=1785312818387:13:38)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:14:23.430Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at SellerLoginPage (http://localhost:3000/src/pages/SellerLoginPage.jsx?t=1785312818387:13:38)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react...

## 2026-07-29 08:14:24.233Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:14:27.527Z navigate
- url: http://localhost:3000/
- via: replaceState

## 2026-07-29 08:14:27.628Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:27.949Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:28.126Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:14:28.127Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:14:30.046Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Reload page"}

## 2026-07-29 08:14:30.069Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:30.275Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:30.430Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:14:30.439Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.j...

## 2026-07-29 08:14:31.256Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:14:36.416Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:36.745Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:14:36.902Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:14:36.903Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:15:03.438Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:15:05.763Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:06.000Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:06.131Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:15:06.132Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:15:08.032Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Reload page"}

## 2026-07-29 08:15:08.048Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:08.182Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:08.277Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:15:08.312Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.j...

## 2026-07-29 08:15:08.697Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:15:10.800Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:11.013Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:11.105Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:15:11.108Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:15:21.688Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:15:26.326Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:15:26.330Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387
- line: 1020
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387:1020:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:26.342Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387
- line: 1020
- col: 38
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387:1020:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:15:26.351Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:15:26.354Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387:1020:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=...

## 2026-07-29 08:15:28.831Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Reload page"}

## 2026-07-29 08:15:29.461Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:15:51.102Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:15:52.854Z navigate
- url: http://127.0.0.1:3000/
- via: replaceState

## 2026-07-29 08:15:58.998Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Become a Seller"}

## 2026-07-29 08:15:59.001Z navigate
- url: http://127.0.0.1:3000/become-a-seller
- via: pushState

## 2026-07-29 08:16:03.664Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Start selling today"}

## 2026-07-29 08:16:03.666Z navigate
- url: http://127.0.0.1:3000/seller/register
- via: pushState

## 2026-07-29 08:16:11.062Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:16:13.653Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:16:13.940Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://localhost:3000/src/components/Header.jsx?t=1785312818387
- line: 705
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:16:14.060Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)
        at div
        at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:16:14.062Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:705:170)
        at renderWithHooks (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://localhost:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://localhost:3000/src/components/Header.jsx?t=1785312818387:369:35)\n    at div\n    at HomePage (http://localhost:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://localhost:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://localhost:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://localhost:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://localhost:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://localhost:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://localhost:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:16:21.026Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"storeName","placeholder":"Studio Lume","label":"Store name","value":"","valueLength":0,"text":""}

## 2026-07-29 08:16:21.229Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"storeName","placeholder":"Studio Lume","label":"Store name","value":"","valueLength":0,"text":""}

## 2026-07-29 08:16:22.418Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"storeName","placeholder":"Studio Lume","label":"Store name","value":"jazzy","valueLength":5,"text":""}

## 2026-07-29 08:16:23.061Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"storeName","placeholder":"Studio Lume","label":"Store name","value":"jazzy","valueLength":5,"text":""}

## 2026-07-29 08:16:23.062Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"name","placeholder":"Jane Doe","label":"Your name","value":"","valueLength":0,"text":""}

## 2026-07-29 08:16:23.286Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"name","placeholder":"Jane Doe","label":"Your name","value":"","valueLength":0,"text":""}

## 2026-07-29 08:16:25.045Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"name","placeholder":"Jane Doe","label":"Your name","value":"PVAFarm","valueLength":7,"text":""}

## 2026-07-29 08:16:27.059Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":"name","placeholder":"Jane Doe","label":"Your name","value":"PVAFarm","valueLength":7,"text":""}

## 2026-07-29 08:16:27.059Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email","value":"","valueLength":0,"text":""}

## 2026-07-29 08:16:27.270Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email","value":"","valueLength":0,"text":""}

## 2026-07-29 08:16:30.258Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email","value":"admin@gmail.com","valueLength":15,"text":""}

## 2026-07-29 08:16:30.942Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email","value":"admin@gmail.com","valueLength":15,"text":""}

## 2026-07-29 08:16:30.943Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"At least 6 characters","label":"Password","value":"[redacted:length=0]","valueLength":0,"text":""}

## 2026-07-29 08:16:31.150Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"At least 6 characters","label":"Password","value":"[redacted:length=0]","valueLength":0,"text":""}

## 2026-07-29 08:16:36.770Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"At least 6 characters","label":"Password","value":"[redacted:length=8]","valueLength":8,"text":""}

## 2026-07-29 08:16:36.770Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"At least 6 characters","label":"Password","value":"[redacted:length=8]","valueLength":8,"text":""}

## 2026-07-29 08:16:36.771Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"checkbox","id":null,"placeholder":null,"label":"I agree to the Seller Terms & Conditions and licensing policies.","value":"on","valueLength":2,"text":""}

## 2026-07-29 08:16:36.975Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"checkbox","id":null,"placeholder":null,"label":"I agree to the Seller Terms & Conditions and licensing policies.","value":"on","valueLength":2,"text":""}

## 2026-07-29 08:16:36.981Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"checkbox","id":null,"placeholder":null,"label":"I agree to the Seller Terms & Conditions and licensing policies.","value":"on","valueLength":2,"text":""}

## 2026-07-29 08:16:37.940Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"checkbox","id":null,"placeholder":null,"label":"I agree to the Seller Terms & Conditions and licensing policies.","value":"on","valueLength":2,"text":""}

## 2026-07-29 08:16:38.129Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"submit","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Create store"}

## 2026-07-29 08:16:38.133Z submit
- action: http://127.0.0.1:3000/seller/register
- fields: [{"label":"Store name","type":"text","value":"jazzy","length":5,"redacted":false},{"label":"Your name","type":"text","value":"PVAFarm","length":7,"redacted":false},{"label":"Email","type":"email","value":"admin@gmail.com","length":15,"redacted":false},{"label":"Password","type":"password","value":"[redacted:length=8]","length":8,"redacted":true},{"label":"Show password","type":"button","value":"","length":0,"redacted":false},{"label":"I agree to the Seller Terms & Conditions and licensing policies.","type":"checkbox","value":"on","length":2,"redacted":false},{"label":"[submit]","type":"submit","value":"","length":0,"redacted":false}]

## 2026-07-29 08:16:38.135Z navigate
- url: http://127.0.0.1:3000/
- via: replaceState

## 2026-07-29 08:16:45.833Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Seller workspace"}

## 2026-07-29 08:16:53.992Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Back to Marketplace"}

## 2026-07-29 08:16:54.017Z navigate
- url: http://127.0.0.1:3000/become-a-seller
- via: popstate

## 2026-07-29 08:17:04.564Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:17:04.565Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:17:07.249Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Seller workspace"}

## 2026-07-29 08:17:13.312Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Back to Marketplace"}

## 2026-07-29 08:17:13.327Z navigate
- url: http://127.0.0.1:3000/become-a-seller
- via: popstate

## 2026-07-29 08:17:16.689Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:17:16.690Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:17:29.910Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:17:40.335Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:17:46.425Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open seller sidebar","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Seller workspace"}

## 2026-07-29 08:17:48.464Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Logout"}

## 2026-07-29 08:17:48.467Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:17:54.636Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $500.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$500.00"}

## 2026-07-29 08:17:54.637Z navigate
- url: http://127.0.0.1:3000/wallet
- via: pushState

## 2026-07-29 08:17:54.695Z navigate
- url: http://127.0.0.1:3000/login
- via: replaceState

## 2026-07-29 08:18:02.155Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $500.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$500.00"}

## 2026-07-29 08:18:02.156Z navigate
- url: http://127.0.0.1:3000/wallet
- via: pushState

## 2026-07-29 08:18:02.187Z navigate
- url: http://127.0.0.1:3000/login
- via: replaceState

## 2026-07-29 08:18:05.185Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:18:05.185Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:18:17.526Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $500.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$500.00"}

## 2026-07-29 08:18:17.527Z navigate
- url: http://127.0.0.1:3000/wallet
- via: pushState

## 2026-07-29 08:18:17.579Z navigate
- url: http://127.0.0.1:3000/login
- via: replaceState

## 2026-07-29 08:18:20.634Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:18:20.635Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:21:09.218Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:09.240Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:09.261Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:21:09.266Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=...

## 2026-07-29 08:21:09.547Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:09.564Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:09.576Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:21:09.579Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at updateFunctionComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14630:28)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15972:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313264991:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=...

## 2026-07-29 08:21:14.709Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:14.792Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:14.850Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:21:14.852Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.j...

## 2026-07-29 08:21:14.727Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:14.824Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:21:14.942Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:21:14.943Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785312818387:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.j...

## 2026-07-29 08:22:09.669Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:22:10.797Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:10.889Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:10.933Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:10.933Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:22:18.935Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:22:19.988Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:20.114Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:20.184Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:20.186Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:22:22.450Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Reload page"}

## 2026-07-29 08:22:22.461Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:22.539Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:22.606Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:22.607Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.j...

## 2026-07-29 08:22:22.683Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:22:23.450Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:23.549Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:23.603Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:23.603Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:22:24.831Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Back to Home"}

## 2026-07-29 08:22:25.180Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:22:25.983Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:26.093Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:26.151Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:26.151Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:22:27.241Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Back to Home"}

## 2026-07-29 08:22:27.386Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:22:28.124Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:28.210Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:28.260Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:28.261Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:22:57.110Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:22:58.843Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:58.998Z window.error
- message: Uncaught ReferenceError: User is not defined
- source: http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233
- line: 706
- col: 170
- stack: 
    ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:22:59.091Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:22:59.092Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: User is not defined
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:706:170)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performConcurrentWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18734:30) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785313274233:369:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785313274233:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 08:25:19.478Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:25:29.646Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:25:30.876Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 08:25:36.562Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign in"}

## 2026-07-29 08:25:36.565Z navigate
- url: http://127.0.0.1:3000/login
- via: pushState

## 2026-07-29 08:26:04.335Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign up"}

## 2026-07-29 08:26:04.336Z navigate
- url: http://127.0.0.1:3000/register
- via: pushState

## 2026-07-29 08:29:09.775Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:29:29.334Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:34:55.550Z load
- url: http://127.0.0.1:3000/register
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:35:22.008Z load
- url: http://127.0.0.1:3000/register
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:43:04.514Z load
- url: http://127.0.0.1:3000/register
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:43:15.175Z load
- url: http://127.0.0.1:3000/register
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:43:20.895Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Log in"}

## 2026-07-29 08:43:20.897Z navigate
- url: http://127.0.0.1:3000/login
- via: pushState

## 2026-07-29 08:46:19.686Z window.error
- message: Uncaught ReferenceError: FaGoogle is not defined
- source: http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270
- line: 156
- col: 38
- stack: 
    ReferenceError: FaGoogle is not defined
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270:156:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:46:19.718Z window.error
- message: Uncaught ReferenceError: FaGoogle is not defined
- source: http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270
- line: 156
- col: 38
- stack: 
    ReferenceError: FaGoogle is not defined
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270:156:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:46:19.728Z console.error
- text: 
    The above error occurred in the <LoginPage> component:
    
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270:15:21)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:46:19.730Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: FaGoogle is not defined
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270:156:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314778270:15:21)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/reac...

## 2026-07-29 08:46:21.700Z window.error
- message: Uncaught ReferenceError: FaGoogle is not defined
- source: http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868
- line: 156
- col: 38
- stack: 
    ReferenceError: FaGoogle is not defined
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868:156:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:46:21.712Z window.error
- message: Uncaught ReferenceError: FaGoogle is not defined
- source: http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868
- line: 156
- col: 38
- stack: 
    ReferenceError: FaGoogle is not defined
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868:156:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)

## 2026-07-29 08:46:21.714Z console.error
- text: 
    The above error occurred in the <LoginPage> component:
    
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868:15:21)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 08:46:21.715Z console.error
- text: 
    ErrorBoundary caught: ReferenceError: FaGoogle is not defined
        at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868:156:38)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18786:28)
        at performSyncWorkOnRoot (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=972594f7:18932:28) {"componentStack":"\n    at LoginPage (http://127.0.0.1:3000/src/pages/LoginPage.jsx?t=1785314780868:15:21)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/reac...

## 2026-07-29 08:47:56.270Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Create Account"}

## 2026-07-29 08:47:56.271Z navigate
- url: http://127.0.0.1:3000/register
- via: pushState

## 2026-07-29 08:48:11.250Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Continue with Google"}

## 2026-07-29 08:48:11.532Z load
- url: http://127.0.0.1:3000/auth/google
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 08:48:13.152Z navigate
- url: http://127.0.0.1:3000/auth/google
- via: replaceState

## 2026-07-29 08:48:17.776Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:48:17.777Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:48:22.861Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign in"}

## 2026-07-29 08:48:22.862Z navigate
- url: http://127.0.0.1:3000/login
- via: pushState

## 2026-07-29 08:48:28.730Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:48:29.647Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email Address","value":"","valueLength":0,"text":""}

## 2026-07-29 08:48:29.875Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email Address","value":"","valueLength":0,"text":""}

## 2026-07-29 08:48:32.833Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email Address","value":"admin@gmail.com","valueLength":15,"text":""}

## 2026-07-29 08:48:34.186Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"you@example.com","label":"Email Address","value":"admin@gmail.com","valueLength":15,"text":""}

## 2026-07-29 08:48:34.187Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"Enter your password","label":"Password","value":"[redacted:length=0]","valueLength":0,"text":""}

## 2026-07-29 08:48:34.406Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"Enter your password","label":"Password","value":"[redacted:length=0]","valueLength":0,"text":""}

## 2026-07-29 08:48:37.622Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"Enter your password","label":"Password","value":"[redacted:length=8]","valueLength":8,"text":""}

## 2026-07-29 08:48:37.622Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"submit","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign In"}

## 2026-07-29 08:48:37.624Z submit
- action: http://127.0.0.1:3000/login
- fields: [{"label":"Email Address","type":"email","value":"admin@gmail.com","length":15,"redacted":false},{"label":"Password","type":"password","value":"[redacted:length=8]","length":8,"redacted":true},{"label":"Show password","type":"button","value":"","length":0,"redacted":false},{"label":"Remember Me","type":"checkbox","value":"on","length":2,"redacted":false},{"label":"[submit]","type":"submit","value":"","length":0,"redacted":false}]

## 2026-07-29 08:48:38.127Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:48:38.238Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"Enter your password","label":"Password","value":"[redacted:length=8]","valueLength":8,"text":""}

## 2026-07-29 08:48:45.762Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $500.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$500.00"}

## 2026-07-29 08:48:45.763Z navigate
- url: http://127.0.0.1:3000/wallet
- via: pushState

## 2026-07-29 08:49:01.011Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Orders"}

## 2026-07-29 08:49:01.013Z navigate
- url: http://127.0.0.1:3000/orders
- via: pushState

## 2026-07-29 08:49:04.935Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Downloads"}

## 2026-07-29 08:49:04.936Z navigate
- url: http://127.0.0.1:3000/downloads
- via: pushState

## 2026-07-29 08:49:17.198Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Dashboard"}

## 2026-07-29 08:49:17.199Z navigate
- url: http://127.0.0.1:3000/dashboard
- via: pushState

## 2026-07-29 08:49:33.893Z click
- element: {"tag":"button","role":null,"ariaLabel":"Quick view E-commerce Marketplace Source Code — MERN Stack","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Quick View"}

## 2026-07-29 08:49:35.982Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Buy Now"}

## 2026-07-29 08:49:47.284Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Close"}

## 2026-07-29 08:49:52.387Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Source CodesInstant delivery"}

## 2026-07-29 08:49:55.965Z click
- element: {"tag":"a","role":null,"ariaLabel":"E-commerce Marketplace Source Code — MERN Stack","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Quick View"}

## 2026-07-29 08:49:55.966Z navigate
- url: http://127.0.0.1:3000/product/prod-9
- via: pushState

## 2026-07-29 08:50:14.363Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Buy 1 — $249.00"}

## 2026-07-29 08:51:04.103Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Confirm Purchase"}

## 2026-07-29 08:51:04.107Z navigate
- url: http://127.0.0.1:3000/orders/ORD-DDQTG5
- via: pushState

## 2026-07-29 08:51:29.245Z click
- element: {"tag":"button","role":null,"ariaLabel":"Notifications, 1 unread","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"1"}

## 2026-07-29 08:51:31.853Z click
- element: {"tag":"button","role":null,"ariaLabel":"Notifications, 1 unread","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"1"}

## 2026-07-29 08:52:22.704Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Shop"}

## 2026-07-29 08:52:22.705Z navigate
- url: http://127.0.0.1:3000/shop
- via: pushState

## 2026-07-29 08:52:30.888Z click
- element: {"tag":"a","role":null,"ariaLabel":"Fitness Tracker App Template — iOS + Android","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sale Quick View"}

## 2026-07-29 08:52:30.889Z navigate
- url: http://127.0.0.1:3000/product/prod-10
- via: pushState

## 2026-07-29 08:52:41.232Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Buy 1 — $149.00"}

## 2026-07-29 08:53:15.591Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Close"}

## 2026-07-29 08:53:18.090Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:53:18.092Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:53:32.458Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $251.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$251.00"}

## 2026-07-29 08:53:32.459Z navigate
- url: http://127.0.0.1:3000/wallet
- via: pushState

## 2026-07-29 08:53:42.946Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $251.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$251.00"}

## 2026-07-29 08:53:42.947Z navigate
- url: http://127.0.0.1:3000/wallet
- via: replaceState

## 2026-07-29 08:53:45.476Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $251.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$251.00"}

## 2026-07-29 08:53:45.477Z navigate
- url: http://127.0.0.1:3000/wallet
- via: replaceState

## 2026-07-29 08:53:47.482Z click
- element: {"tag":"button","role":null,"ariaLabel":"Notifications, 1 unread","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"1"}

## 2026-07-29 08:53:50.535Z click
- element: {"tag":"button","role":null,"ariaLabel":"Notifications, 1 unread","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"1"}

## 2026-07-29 08:53:53.367Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:53:53.368Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 08:53:58.130Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Become a Seller"}

## 2026-07-29 08:53:58.131Z navigate
- url: http://127.0.0.1:3000/become-a-seller
- via: pushState

## 2026-07-29 08:54:02.283Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Start selling today"}

## 2026-07-29 08:54:02.284Z navigate
- url: http://127.0.0.1:3000/seller/register
- via: pushState

## 2026-07-29 08:55:58.806Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Shop"}

## 2026-07-29 08:55:58.807Z navigate
- url: http://127.0.0.1:3000/shop
- via: pushState

## 2026-07-29 08:56:04.499Z click
- element: {"tag":"a","role":null,"ariaLabel":"Fitness Tracker App Template — iOS + Android","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sale Quick View"}

## 2026-07-29 08:56:04.500Z navigate
- url: http://127.0.0.1:3000/product/prod-10
- via: pushState

## 2026-07-29 08:56:08.373Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Buy 1 — $149.00"}

## 2026-07-29 08:56:14.704Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Confirm Purchase"}

## 2026-07-29 08:56:14.707Z navigate
- url: http://127.0.0.1:3000/orders/ORD-48LOU4
- via: pushState

## 2026-07-29 08:56:20.527Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Orders"}

## 2026-07-29 08:56:20.529Z navigate
- url: http://127.0.0.1:3000/orders
- via: pushState

## 2026-07-29 08:56:34.347Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Payment Methods"}

## 2026-07-29 08:56:34.348Z navigate
- url: http://127.0.0.1:3000/payment-methods
- via: pushState

## 2026-07-29 08:56:47.799Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 08:56:47.799Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 09:00:52.123Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:00:57.586Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Become a Seller"}

## 2026-07-29 09:00:57.591Z navigate
- url: http://127.0.0.1:3000/become-a-seller
- via: pushState

## 2026-07-29 09:01:00.966Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Start selling today"}

## 2026-07-29 09:01:00.968Z navigate
- url: http://127.0.0.1:3000/seller/register
- via: pushState

## 2026-07-29 09:01:07.594Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign in"}

## 2026-07-29 09:01:07.594Z navigate
- url: http://127.0.0.1:3000/seller/login
- via: pushState

## 2026-07-29 09:01:17.462Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:01:17.462Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 09:01:40.587Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Instagram Growth Account"}

## 2026-07-29 09:01:43.050Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Instagram"}

## 2026-07-29 09:02:25.514Z load
- url: http://127.0.0.1:3000/admin
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:02:26.962Z navigate
- url: http://127.0.0.1:3000/admin
- via: replaceState

## 2026-07-29 09:02:26.999Z navigate
- url: http://127.0.0.1:3000/admin/login
- via: replaceState

## 2026-07-29 09:02:33.177Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"admin@hstock.store","label":"Email","value":"","valueLength":0,"text":""}

## 2026-07-29 09:02:33.394Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"admin@hstock.store","label":"Email","value":"","valueLength":0,"text":""}

## 2026-07-29 09:02:50.443Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"admin@hstock.store","label":"Email","value":"admin@hstock.store","valueLength":18,"text":""}

## 2026-07-29 09:02:50.445Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"email","id":"email","placeholder":"admin@hstock.store","label":"Email","value":"admin@hstock.store","valueLength":18,"text":""}

## 2026-07-29 09:02:50.446Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"••••••••","label":"Password","value":"[redacted:length=0]","valueLength":0,"text":""}

## 2026-07-29 09:02:50.658Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"••••••••","label":"Password","value":"[redacted:length=0]","valueLength":0,"text":""}

## 2026-07-29 09:02:54.665Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"••••••••","label":"Password","value":"[redacted:length=8]","valueLength":8,"text":""}

## 2026-07-29 09:02:54.665Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"password","id":"password","placeholder":"••••••••","label":"Password","value":"[redacted:length=8]","valueLength":8,"text":""}

## 2026-07-29 09:02:54.876Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"submit","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign in"}

## 2026-07-29 09:02:54.877Z submit
- action: http://127.0.0.1:3000/admin/login
- fields: [{"label":"Email","type":"email","value":"admin@hstock.store","length":18,"redacted":false},{"label":"Password","type":"password","value":"[redacted:length=8]","length":8,"redacted":true},{"label":"Show password","type":"button","value":"","length":0,"redacted":false},{"label":"[submit]","type":"submit","value":"","length":0,"redacted":false}]

## 2026-07-29 09:02:54.877Z navigate
- url: http://127.0.0.1:3000/admin
- via: replaceState

## 2026-07-29 09:02:54.878Z navigate
- url: http://127.0.0.1:3000/admin
- via: replaceState

## 2026-07-29 09:02:54.894Z console.error
- text: 
    Warning: Cannot update a component (`%s`) while rendering a different component (`%s`). To locate the bad setState() call inside `%s`, follow the stack trace as described in https://reactjs.org/link/setstate-in-render%s BrowserRouter AdminLoginPage AdminLoginPage 
        at AdminLoginPage (http://127.0.0.1:3000/src/admin/pages/AdminLoginPage.jsx:10:38)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=b8edba6c:10816:3)
        at App

## 2026-07-29 09:03:24.651Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Site Settings"}

## 2026-07-29 09:03:29.232Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Site Settings"}

## 2026-07-29 09:03:45.231Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sellers"}

## 2026-07-29 09:03:45.235Z navigate
- url: http://127.0.0.1:3000/admin/sellers
- via: pushState

## 2026-07-29 09:03:54.530Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:03:56.379Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:04:08.155Z click
- element: {"tag":"td","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"5"}

## 2026-07-29 09:04:11.790Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":null,"placeholder":null,"label":"[number]","value":"15","valueLength":2,"text":""}

## 2026-07-29 09:04:12.001Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":null,"placeholder":null,"label":"[number]","value":"15","valueLength":2,"text":""}

## 2026-07-29 09:04:19.509Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":null,"placeholder":null,"label":"[number]","value":"15","valueLength":2,"text":""}

## 2026-07-29 09:04:19.714Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:04:22.297Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:04:24.622Z click
- element: {"tag":"div","role":"menuitem","ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Edit"}

## 2026-07-29 09:04:30.295Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Close"}

## 2026-07-29 09:04:34.434Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:04:35.950Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:05:17.352Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Settings"}

## 2026-07-29 09:05:17.355Z navigate
- url: http://127.0.0.1:3000/admin/settings
- via: pushState

## 2026-07-29 09:05:25.134Z click
- element: {"tag":"button","role":"tab","ariaLabel":null,"name":null,"type":"button","id":"radix-:r18:-trigger-finance","placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Shipping & Fees"}

## 2026-07-29 09:05:36.447Z click
- element: {"tag":"button","role":"tab","ariaLabel":null,"name":null,"type":"button","id":"radix-:r18:-trigger-notifications","placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Notifications"}

## 2026-07-29 09:05:42.899Z click
- element: {"tag":"button","role":"tab","ariaLabel":null,"name":null,"type":"button","id":"radix-:r18:-trigger-advanced","placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Advanced"}

## 2026-07-29 09:05:46.805Z click
- element: {"tag":"button","role":"tab","ariaLabel":null,"name":null,"type":"button","id":"radix-:r18:-trigger-general","placeholder":null,"label":null,"value":null,"valueLength":0,"text":"General"}

## 2026-07-29 09:05:53.038Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:05:53.039Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"file","id":null,"placeholder":null,"label":"[file]","value":"","valueLength":0,"text":""}

## 2026-07-29 09:06:09.957Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Save Changes"}

## 2026-07-29 09:06:15.116Z load
- url: http://127.0.0.1:3000/admin
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:06:14.486Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:06:17.781Z navigate
- url: http://127.0.0.1:3000/admin
- via: replaceState

## 2026-07-29 09:06:24.073Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"ATAva Thompson"}

## 2026-07-29 09:06:30.064Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Store Settings"}

## 2026-07-29 09:06:30.069Z navigate
- url: http://127.0.0.1:3000/admin/settings
- via: pushState

## 2026-07-29 09:06:33.444Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"ATAva Thompson"}

## 2026-07-29 09:06:50.158Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Promotional Banners"}

## 2026-07-29 09:06:50.161Z navigate
- url: http://127.0.0.1:3000/admin/banners
- via: pushState

## 2026-07-29 09:06:58.417Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Add Banner"}

## 2026-07-29 09:07:02.859Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:07:02.864Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"file","id":null,"placeholder":null,"label":"[file]","value":"","valueLength":0,"text":""}

## 2026-07-29 09:07:11.501Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:07:11.503Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"file","id":null,"placeholder":null,"label":"[file]","value":"","valueLength":0,"text":""}

## 2026-07-29 09:07:17.736Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":"[input]","value":"","valueLength":0,"text":""}

## 2026-07-29 09:07:17.944Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":"[input]","value":"","valueLength":0,"text":""}

## 2026-07-29 09:07:39.355Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":"[input]","value":"buy gmail accounts","valueLength":18,"text":""}

## 2026-07-29 09:07:39.355Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":"[input]","value":"buy gmail accounts","valueLength":18,"text":""}

## 2026-07-29 09:07:39.451Z click
- element: {"tag":"body","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\tMenuDashboardAnalyticsProductsCategoriesCollectionsBrandsInventoryOrdersCustomersSellersCouponsReviewsMedia LibraryBlogHomepageHeaderFooterNavigation MenusHero SliderPromotional BannersStatic PagesFAQTestimonialsNewsletterPopup ManagerSEO ManagerEmail TemplatesSite SettingsSettingsUser ManagementATAva ThompsonAva Thompsonadmin@hstock.storeStore SettingsUser ManagementView StoreSign out3Notifications×New order #1010 placed by Sam Rivera5 minutes ago\"Championship Sports Badges\" is out of stock2 hours agoNew review pending approval on \"Vintage Sports Tee Graphics\"YesterdayAdd ProductDashboardProductsInventoryOrdersCustomersAdminDashboardAnalyticsCatalogProductsCategoriesCollectionsBrandsInventorySalesOrdersCustomersSellersCouponsContentReviewsMedia LibraryBlogCMSHomepageHeaderFooterNavigation MenusHero SliderPromotional BannersStatic PagesFAQTestimonialsNewsletterPopup ManagerSEO ManagerEmail TemplatesSite SettingsSystemSettingsUser ManagementPromotional Banners4 banners Add BannerAll StatusBannerPositionStatusActionsSummer Sale — Up to 40% Off Social AccountsHomepage BannerActiveNew Arrivals: Premium DomainsCollection BannerActiveLaunch Your SaaS — Starter KitsCategory BannerScheduledAI Tools Launch WeekSale BannerDraft\n\t\t\n\t\t// plugins/visual-editor/state/editing-state.js\nvar current = null;\nfunction getEditing() {\n  return current;\n}\nfunction setEditing(info) {\n  current = info;\n}\nfunction clearEditing() {\n  current = null;\n}\n\n// plugins/visual-editor/utils/html-utils.js\nfunction escapeHtml(string) {\n  return string.replace(/&/g, \"&amp;\").replace(/</g, \"&lt;\").replace(/>/g, \"&gt;\");\n}\nfunction nextNodeInFlow(node, root) {\n  if (node.firstChild) return node.firstChild;\n  let current2 = node;\n  while (current2 && current2 !== root) {\n    if (current2.nextSibling) return current2.nextSibling;\n    current2 = current2.parentNode;\n  }\n  return null;\n}\nfunction isAtLineEnd(node, root) {\n  const next = nextNodeInFlow(node, root);\n  if (!next) return true;\n  let candidate ..."}

## 2026-07-29 09:07:41.069Z change
- element: {"tag":"select","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":"[select]","value":"active","valueLength":6,"text":"ActiveScheduledDraft"}

## 2026-07-29 09:07:41.073Z click
- element: {"tag":"div","role":"option","ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Active"}

## 2026-07-29 09:07:42.697Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"submit","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Save"}

## 2026-07-29 09:07:42.707Z submit
- action: http://127.0.0.1:3000/admin/banners
- fields: [{"label":"Remove image","type":"button","value":"","length":0,"redacted":false},{"label":"[file]","type":"file","value":"","length":0,"redacted":false},{"label":"Remove image","type":"button","value":"","length":0,"redacted":false},{"label":"[file]","type":"file","value":"","length":0,"redacted":false},{"label":"[input]","type":"text","value":"buy gmail accounts","length":18,"redacted":false},{"label":"/shop?search=sale","type":"text","value":"","length":0,"redacted":false},{"label":"e.g. Shop Now","type":"text","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[select]","type":"select-one","value":"homepage","length":8,"redacted":false},{"label":"[date]","type":"date","value":"","length":0,"redacted":false},{"label":"[date]","type":"date","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[select]","type":"select-one","value":"active","length":6,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[submit]","type":"submit","value":"","length":0,"redacted":false}]

## 2026-07-29 09:07:51.337Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"ATAva Thompson"}

## 2026-07-29 09:07:52.826Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Sign out"}

## 2026-07-29 09:07:52.829Z navigate
- url: http://127.0.0.1:3000/admin/login
- via: pushState

## 2026-07-29 09:07:52.859Z navigate
- url: http://127.0.0.1:3000/admin/login
- via: replaceState

## 2026-07-29 09:07:56.832Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"← Back to store"}

## 2026-07-29 09:07:56.835Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 09:08:06.746Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:08:21.570Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:08:22.836Z click
- element: {"tag":"div","role":"menuitem","ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Delete"}

## 2026-07-29 09:08:29.500Z click
- element: {"tag":"body","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\tMenuDashboardAnalyticsProductsCategoriesCollectionsBrandsInventoryOrdersCustomersSellersCouponsReviewsMedia LibraryBlogHomepageHeaderFooterNavigation MenusHero SliderPromotional BannersStatic PagesFAQTestimonialsNewsletterPopup ManagerSEO ManagerEmail TemplatesSite SettingsSettingsUser ManagementATAva ThompsonAva Thompsonadmin@hstock.storeStore SettingsUser ManagementView StoreSign out3Notifications×New order #1010 placed by Sam Rivera5 minutes ago\"Championship Sports Badges\" is out of stock2 hours agoNew review pending approval on \"Vintage Sports Tee Graphics\"YesterdayAdd ProductDashboardProductsInventoryOrdersCustomersAdminDashboardAnalyticsCatalogProductsCategoriesCollectionsBrandsInventorySalesOrdersCustomersSellersCouponsContentReviewsMedia LibraryBlogCMSHomepageHeaderFooterNavigation MenusHero SliderPromotional BannersStatic PagesFAQTestimonialsNewsletterPopup ManagerSEO ManagerEmail TemplatesSite SettingsSystemSettingsUser ManagementPromotional Banners5 banners Add BannerAll StatusBannerPositionStatusActionsbuy gmail accountsHomepage BannerActiveSummer Sale — Up to 40% Off Social AccountsHomepage BannerActiveNew Arrivals: Premium DomainsCollection BannerActiveLaunch Your SaaS — Starter KitsCategory BannerScheduledAI Tools Launch WeekSale BannerDraft\n\t\t\n\t\t// plugins/visual-editor/state/editing-state.js\nvar current = null;\nfunction getEditing() {\n  return current;\n}\nfunction setEditing(info) {\n  current = info;\n}\nfunction clearEditing() {\n  current = null;\n}\n\n// plugins/visual-editor/utils/html-utils.js\nfunction escapeHtml(string) {\n  return string.replace(/&/g, \"&amp;\").replace(/</g, \"&lt;\").replace(/>/g, \"&gt;\");\n}\nfunction nextNodeInFlow(node, root) {\n  if (node.firstChild) return node.firstChild;\n  let current2 = node;\n  while (current2 && current2 !== root) {\n    if (current2.nextSibling) return current2.nextSibling;\n    current2 = current2.parentNode;\n  }\n  return null;\n}\nfunction isAtLineEnd(node, root) {\n  const next = nextNodeInFlow(node, root);\n  i..."}

## 2026-07-29 09:08:32.143Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:08:35.206Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Close"}

## 2026-07-29 09:08:37.120Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Delete"}

## 2026-07-29 09:08:40.456Z click
- element: {"tag":"html","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"\n\t\timport { injectIntoGlobalHook } from \"/@react-refresh\";\ninjectIntoGlobalHook(window);\nwindow.$RefreshReg$ = () => {};\nwindow.$RefreshSig$ = () => (type) => type;\n\n\t\t\n\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\t\n\t\tHStock.store — Premium Digital Art Marketplace\n\t\t\n\t\tconst SITE_PAGES_ENDPOINT = '/__horizons/site-pages';\n\nconst OUTGOING_SITE_PAGES_MESSAGE = 'sitePages';\nconst INCOMING_REQUEST_SITE_PAGES_MESSAGE = 'request-site-pages';\n\nconst ALLOWED_PARENT_ORIGINS = [\n\t'https://horizons.hostinger.com',\n\t'https://horizons.hostinger.dev',\n\t'https://horizons-frontend-local.hostinger.dev',\n\t'http://localhost:4000',\n];\n\nfunction postSitePages(pages) {\n\tlet parentOrigin = window.location.ancestorOrigins?.[0];\n\tif (!parentOrigin && document.referrer) {\n\t\ttry {\n\t\t\tparentOrigin = new URL(document.referrer).origin;\n\t\t} catch {}\n\t}\n\tif (parentOrigin && ALLOWED_PARENT_ORIGINS.includes(parentOrigin)) {\n\t\twindow.parent.postMessage({ type: OUTGOING_SITE_PAGES_MESSAGE, payload: { pages } }, parentOrigin);\n\t}\n}\n\nasync function sendSitePagesToParent() {\n\tif (window.self === window.top) {\n\t\treturn;\n\t}\n\n\ttry {\n\t\tconst response = await fetch(SITE_PAGES_ENDPOINT);\n\t\tif (!response.ok) {\n\t\t\tthrow new Error(`HTTP ${response.status}`);\n\t\t}\n\t\tpostSitePages(await response.json());\n\t} catch (error) {\n\t\tconsole.error('[site-pages] Failed to send site pages to parent:', error);\n\t}\n}\n\nif (window.self !== window.top) {\n\twindow.addEventListener('load', sendSitePagesToParent);\n\twindow.addEventListener('message', (event) => {\n\t\tif (event.data?.type === INCOMING_REQUEST_SITE_PAGES_MESSAGE) {\n\t\t\tsendSitePagesToParent();\n\t\t}\n\t});\n}\n\n\t\t\n\t#root[data-edit-mode-enabled=\"true\"] {\n\t\tcursor: pointer;\n\t}\n\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id] {\n\t\tcursor: pointer;\n\t\toutline: 2px dashed #357DF9;\n\t\toutline-offset: 2px;\n\t\tmin-height: 1em;\n\t\toverflow-wrap: anywhere;\n\t\tmin-width: 0;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] img[data-edit-id] {\n\t\toutline-offset: -2px;\n\t}\n\t#root[data-edit-mode-enabled=\"true\"] [data-edit-id]:ho..."}

## 2026-07-29 09:08:41.871Z click
- element: {"tag":"div","role":"menuitem","ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Delete"}

## 2026-07-29 09:08:44.495Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Close"}

## 2026-07-29 09:08:46.093Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Delete"}

## 2026-07-29 09:08:52.073Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:14:23.235Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:16:42.219Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:16:43.703Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d1bfb5da' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:16:43.713Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:16:56.673Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d1bfb5da' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:16:56.781Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:09.058Z window.error
- message: Uncaught SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'
- source: http://127.0.0.1:3000/src/components/HeroSection.jsx?t=1785316425677
- line: 26
- col: 3
- stack: SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:09.185Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:09.188Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:09.232Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:09.233Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:09.640Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:09.640Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:09.681Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:09.683Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:10.054Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:10.056Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:09.404Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d1bfb5da' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:09.405Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:10.446Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:10.447Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:10.899Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:10.901Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:11.864Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:11.866Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:11.944Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:11.944Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:12.286Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:12.286Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:13.891Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:17:17.042Z window.error
- message: Uncaught SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'
- source: http://127.0.0.1:3000/src/components/HeroSection.jsx?t=1785316425677
- line: 26
- col: 3
- stack: SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:19.287Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:19.299Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:19.452Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:19.453Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:19.600Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:19.602Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:19.818Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:19.820Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:20.352Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:20.354Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:20.454Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:20.478Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:20.711Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:20.712Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:20.994Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.002Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.331Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.332Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.423Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.424Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.599Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.601Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.761Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.761Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.929Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.929Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.964Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.965Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:22.198Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:22.199Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:22.273Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:22.276Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.344Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.349Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.534Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.535Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.648Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.648Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:21.780Z console.error
- text: [vite] SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:21.782Z console.error
- text: [vite] Failed to reload /src/components/HeroSection.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:17:23.270Z load
- url: http://127.0.0.1:3000/admin/banners
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:17:23.832Z load
- url: http://localhost:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:17:28.303Z window.error
- message: Uncaught SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'
- source: http://127.0.0.1:3000/src/components/HeroSection.jsx?t=1785316425677
- line: 26
- col: 3
- stack: SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:17:29.763Z window.error
- message: Uncaught SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'
- source: http://localhost:3000/src/components/HeroSection.jsx?t=1785316425677
- line: 26
- col: 3
- stack: SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:22:00.386Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:22:19.186Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:25:13.634Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:39:23.969Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:24.243Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:24.284Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:24.287Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:39:24.798Z console.error
- text: [vite] Failed to reload /src/pages/account/PaymentMethodsPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:39:25.529Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:25.677Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:25.681Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:25.682Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:39:25.784Z console.error
- text: [vite] Failed to reload /src/pages/account/PaymentMethodsPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:39:25.634Z console.error
- text: [vite] Failed to reload /src/pages/account/PaymentMethodsPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:39:25.931Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317961400:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:26.351Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:26.396Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317961400:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:26.597Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:26.652Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317961400:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:26.660Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317961400:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317961400:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:39:26.662Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:26.663Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:39:28.082Z console.error
- text: [vite] Failed to reload /src/pages/account/PaymentMethodsPage.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:39:28.761Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:29.176Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:29.514Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:30.393Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:30.408Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:30.410Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:39:30.424Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:30.426Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:39:30.108Z console.error
- text: [vite] Failed to reload /src/app/router.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:39:32.044Z console.error
- text: [vite] Failed to reload /src/app/router.jsx. This could be due to syntax errors or importing non-existent modules. (see errors above)

## 2026-07-29 09:39:32.861Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:33.138Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:33.176Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:33.456Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:39:33.476Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:33.504Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:39:33.506Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:39:33.509Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:40:10.439Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:40:10.648Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:40:10.735Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:40:10.950Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:40:10.965Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:40:10.976Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:40:10.978Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:40:10.980Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:41:14.625Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:41:14.892Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:41:14.925Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:41:15.174Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:41:15.178Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:41:15.192Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:41:15.193Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:41:15.194Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:43:07.766Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:08.094Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:08.130Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:08.300Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:08.317Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:43:08.320Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:43:08.323Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:43:08.325Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:43:22.329Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:22.495Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:22.530Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:22.695Z window.error
- message: Uncaught Error: useStore must be used within StoreProvider
- source: http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565
- line: 218
- col: 19
- stack: 
    Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at HTMLUnknownElement.callCallback2 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3680:22)
        at Object.invokeGuardedCallbackDev (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3705:24)
        at invokeGuardedCallback (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:3739:39)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19818:15)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)

## 2026-07-29 09:43:22.698Z console.error
- text: 
    The above error occurred in the <Header> component:
    
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)
        at div
        at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)
        at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)
        at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:43:22.708Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:381:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at Header (http://127.0.0.1:3000/src/components/Header.jsx?t=1785317964565:370:35)\n    at div\n    at HomePage (http://127.0.0.1:3000/src/pages/HomePage.jsx?t=1785316825741:172:54)\n    at RenderedRoute (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:6647:26)\n    at Routes (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7572:3)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router...

## 2026-07-29 09:43:22.712Z console.error
- text: 
    The above error occurred in the <CompareBar> component:
    
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)
        at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)
        at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)
        at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)
        at AppRouter
        at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)
        at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)
        at App
    
    React will try to recreate this component tree from scratch using the error boundary you provided, ErrorBoundary.

## 2026-07-29 09:43:22.713Z console.error
- text: 
    ErrorBoundary caught: Error: useStore must be used within StoreProvider
        at useStore (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317964565:218:19)
        at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)
        at renderWithHooks (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:11596:26)
        at mountIndeterminateComponent (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:14974:21)
        at beginWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:15962:22)
        at beginWork$1 (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19806:22)
        at performUnitOfWork (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19251:20)
        at workLoopSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19190:13)
        at renderRootSync (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:19169:15)
        at recoverFromConcurrentError (http://127.0.0.1:3000/node_modules/.vite/deps/chunk-TL6SWKMI.js?v=d380b326:18786:28) {"componentStack":"\n    at CompareBar (http://127.0.0.1:3000/src/components/CompareBar.jsx?t=1785317964565:9:73)\n    at SellerAuthProvider (http://127.0.0.1:3000/src/context/SellerAuthContext.jsx:15:38)\n    at AdminAuthProvider (http://127.0.0.1:3000/src/admin/AdminAuthContext.jsx:14:37)\n    at StoreProvider (http://127.0.0.1:3000/src/context/StoreContext.jsx?t=1785317961400:16:33)\n    at ErrorBoundary (http://127.0.0.1:3000/src/components/ErrorState.jsx:145:5)\n    at AppRouter\n    at Router (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:7511:13)\n    at BrowserRouter (http://127.0.0.1:3000/node_modules/.vite/deps/react-router-dom.js?v=d380b326:10816:3)\n    at App"}

## 2026-07-29 09:43:36.871Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:43:43.527Z load
- url: http://127.0.0.1:3000/admin/banners
- title: HStock.store — Premium Digital Art Marketplace

## 2026-07-29 09:43:54.076Z window.error
- message: Uncaught SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'
- source: http://127.0.0.1:3000/src/components/HeroSection.jsx?t=1785316425677
- line: 26
- col: 3
- stack: SyntaxError: The requested module '/node_modules/.vite/deps/react-icons_si.js?v=d380b326' does not provide an export named 'SiLinkedin'

## 2026-07-29 09:44:12.073Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $102.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$102.00"}

## 2026-07-29 09:44:12.088Z navigate
- url: http://127.0.0.1:3000/wallet
- via: pushState

## 2026-07-29 09:44:31.611Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Tether"}

## 2026-07-29 09:44:33.476Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"BNB Chain"}

## 2026-07-29 09:44:47.559Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$25"}

## 2026-07-29 09:44:54.133Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"submit","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Top Up Wallet"}

## 2026-07-29 09:44:54.138Z submit
- action: http://127.0.0.1:3000/wallet
- fields: [{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"Amount (USD)","type":"number","value":"25","length":2,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[button]","type":"button","value":"","length":0,"redacted":false},{"label":"[submit]","type":"submit","value":"","length":0,"redacted":false}]

## 2026-07-29 09:44:58.207Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 09:45:28.778Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Withdraw"}

## 2026-07-29 09:45:44.344Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"","valueLength":0,"text":""}

## 2026-07-29 09:45:44.563Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"","valueLength":0,"text":""}

## 2026-07-29 09:45:46.992Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1","valueLength":1,"text":""}

## 2026-07-29 09:45:46.993Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1","valueLength":1,"text":""}

## 2026-07-29 09:45:47.416Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.01","valueLength":4,"text":""}

## 2026-07-29 09:45:47.418Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.01","valueLength":4,"text":""}

## 2026-07-29 09:45:47.578Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.02","valueLength":4,"text":""}

## 2026-07-29 09:45:47.580Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.02","valueLength":4,"text":""}

## 2026-07-29 09:45:47.735Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.03","valueLength":4,"text":""}

## 2026-07-29 09:45:47.736Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.03","valueLength":4,"text":""}

## 2026-07-29 09:45:47.959Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.04","valueLength":4,"text":""}

## 2026-07-29 09:45:47.961Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.04","valueLength":4,"text":""}

## 2026-07-29 09:45:50.082Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.04","valueLength":4,"text":""}

## 2026-07-29 09:45:50.228Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.04","valueLength":4,"text":""}

## 2026-07-29 09:45:50.442Z click
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"1.04","valueLength":4,"text":""}

## 2026-07-29 09:45:59.267Z change
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"10.01","valueLength":5,"text":""}

## 2026-07-29 09:45:59.271Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"10.01","valueLength":5,"text":""}

## 2026-07-29 09:48:17.342Z focus
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"10.01","valueLength":5,"text":""}

## 2026-07-29 09:48:24.225Z blur
- element: {"tag":"input","role":null,"ariaLabel":null,"name":null,"type":"number","id":"wallet-amount","placeholder":"0.00","label":"Amount (USD)","value":"10.01","valueLength":5,"text":""}

## 2026-07-29 10:02:49.566Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open account navigation","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 10:02:53.668Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close account navigation","name":null,"type":"button","id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 10:03:09.847Z click
- element: {"tag":"a","role":null,"ariaLabel":"Wallet balance $127.00","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"$127.00"}

## 2026-07-29 10:03:09.856Z navigate
- url: http://127.0.0.1:3000/wallet
- via: replaceState

## 2026-07-29 10:03:11.338Z click
- element: {"tag":"button","role":null,"ariaLabel":"Open mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 10:03:14.493Z click
- element: {"tag":"button","role":null,"ariaLabel":"Close mobile navigation","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 10:03:16.433Z click
- element: {"tag":"a","role":null,"ariaLabel":"HStock home","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-29 10:03:16.450Z navigate
- url: http://127.0.0.1:3000/
- via: pushState

## 2026-07-29 10:16:04.594Z load
- url: http://127.0.0.1:3000/
- title: HStock.store — Premium Digital Art Marketplace

